@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SteadyWin.ps1" %*
echo.
echo Completed. Review the results above. Press any key to close.
pause >nul

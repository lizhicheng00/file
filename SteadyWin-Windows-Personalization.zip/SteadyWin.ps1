﻿#requires -Version 5.1
<#
SteadyWin - a low-noise Windows 10/11 personal setup.
Runs as the CURRENT USER. No administrator rights needed.

Examples:
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\SteadyWin.ps1 -Preview
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\SteadyWin.ps1
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\SteadyWin.ps1 -Theme Light
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\SteadyWin.ps1 -Undo "C:\...\backup-....json"

An individual failure is reported and skipped. To prevent unrecoverable changes,
no setting is modified unless the backup was saved successfully.
#>
[CmdletBinding()]
param(
    [ValidateSet('Dark', 'Light')]
    [string]$Theme = 'Dark',
    [switch]$Preview,
    [string]$Undo = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ($env:OS -ne 'Windows_NT') {
    Write-Host '[ERROR] This script only supports Windows.'
    exit 1
}

$script:LogFile = $null
function Report {
    param([string]$Level, [string]$Message)
    $line = '[{0}] {1}' -f $Level, $Message
    Write-Host $line
    if ($script:LogFile) {
        try {
            Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8 -ErrorAction Stop
        } catch {
            # Logging problems must not interrupt individual settings.
            $script:LogFile = $null
        }
    }
}

function Registry-State {
    param([string]$Path, [string]$Name)
    if (-not (Test-Path -LiteralPath $Path -ErrorAction Stop)) {
        return [pscustomobject]@{ Exists = $false; Value = $null }
    }
    $key = Get-Item -LiteralPath $Path -ErrorAction Stop
    if (@($key.GetValueNames()) -notcontains $Name) {
        return [pscustomobject]@{ Exists = $false; Value = $null }
    }
    $kind = $key.GetValueKind($Name).ToString()
    if ($kind -ne 'DWord') {
        throw "Unexpected registry value type ($kind); will not overwrite it."
    }
    return [pscustomobject]@{
        Exists = $true
        Value  = [int]$key.GetValue($Name)
    }
}

function Write-Dword {
    param([string]$Path, [string]$Name, [int]$Value)
    if (-not (Test-Path -LiteralPath $Path -ErrorAction Stop)) {
        New-Item -Path $Path -Force -ErrorAction Stop | Out-Null
    }
    New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value `
        -PropertyType DWord -Force -ErrorAction Stop | Out-Null
    $state = Registry-State -Path $Path -Name $Name
    if ((-not $state.Exists) -or ($state.Value -ne $Value)) {
        throw 'Value did not match when read back.'
    }
}

$build = [Environment]::OSVersion.Version.Build
$isWindows11 = $build -ge 22000
$light = if ($Theme -eq 'Light') { 1 } else { 0 }

$colors   = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
$dwm      = 'HKCU:\Software\Microsoft\Windows\DWM'
$advanced = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
$explorer = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer'
$search   = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search'

# To change defaults, edit the Value numbers below. All entries are current-user DWORDs.
$settings = @(
    # Visual style: subdued, neutral, with minimal surface decoration.
    [pscustomobject]@{ Label='应用深浅色主题';            Path=$colors;   Name='AppsUseLightTheme';             Value=$light; W11=$false },
    [pscustomobject]@{ Label='Windows 深浅色主题';         Path=$colors;   Name='SystemUsesLightTheme';           Value=$light; W11=$false },
    [pscustomobject]@{ Label='关闭透明效果';        Path=$colors;   Name='EnableTransparency';            Value=0;      W11=$false },
    [pscustomobject]@{ Label='窗口边框低调配色';       Path=$dwm;      Name='ColorPrevalence';               Value=0;      W11=$false },

    # File Explorer: clear file types, stable navigation, fewer recents.
    [pscustomobject]@{ Label='显示文件扩展名';        Path=$advanced; Name='HideFileExt';                  Value=0;      W11=$false },
    [pscustomobject]@{ Label='资源管理器默认打开此电脑';      Path=$advanced; Name='LaunchTo';                     Value=1;      W11=$false },
    [pscustomobject]@{ Label='隐藏主页最近文件';   Path=$explorer; Name='ShowRecent';                   Value=0;      W11=$false },
    [pscustomobject]@{ Label='隐藏常用文件夹';       Path=$explorer; Name='ShowFrequent';                 Value=0;      W11=$false },

    # Taskbar: keep search available (Win+S), but remove the wide search box.
    [pscustomobject]@{ Label='任务栏搜索改为小图标';      Path=$search;   Name='SearchboxTaskbarMode';         Value=1;      W11=$false },
    [pscustomobject]@{ Label='隐藏任务视图图标';       Path=$advanced; Name='ShowTaskViewButton';           Value=0;      W11=$false },

    # Windows 11 only: clean Start and taskbar; do not remove any apps.
    [pscustomobject]@{ Label='任务栏左对齐';          Path=$advanced; Name='TaskbarAl';                    Value=0;      W11=$true  },
    [pscustomobject]@{ Label='隐藏任务栏小组件';        Path=$advanced; Name='TaskbarDa';                    Value=0;      W11=$true  },
    [pscustomobject]@{ Label='开始菜单显示更多固定项';   Path=$advanced; Name='Start_Layout';                 Value=1;      W11=$true  },
    [pscustomobject]@{ Label='减少开始菜单建议';    Path=$advanced; Name='Start_IrisRecommendations';   Value=0;      W11=$true  }
)

$root = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SteadyWin'
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'

if ($Undo) {
    try {
        if (-not (Test-Path -LiteralPath $Undo -PathType Leaf -ErrorAction Stop)) {
            throw 'The specified backup file does not exist.'
        }
        $backup = Get-Content -LiteralPath $Undo -Raw -Encoding UTF8 -ErrorAction Stop |
            ConvertFrom-Json -ErrorAction Stop
        if ([int]$backup.Version -ne 1) { throw 'Unsupported backup format.' }
        if ([string]$backup.User -ne [Environment]::UserName -or
            [string]$backup.Machine -ne $env:COMPUTERNAME) {
            throw 'Backup belongs to a different computer/user; refusing to restore.'
        }
    } catch {
        Report 'ERROR' ("Cannot open backup safely: {0}" -f $_.Exception.Message)
        exit 1
    }
    try {
        New-Item -ItemType Directory -Path $root -Force -ErrorAction Stop | Out-Null
        $script:LogFile = Join-Path $root "undo-$timestamp.log"
    } catch {
        # Restore is still possible without an on-disk log.
    }
    $restored = 0; $skipped = 0; $failed = 0
    foreach ($entry in @($backup.Entries)) {
        # Only restore settings owned by this script, not arbitrary registry paths.
        $known = @($settings | Where-Object {
            $_.Path -eq [string]$entry.Path -and $_.Name -eq [string]$entry.Name
        })
        if ($known.Count -ne 1) {
            Report 'SKIP' 'An unknown backup entry was ignored.'
            $skipped++
            continue
        }
        try {
            $now = Registry-State -Path ([string]$entry.Path) -Name ([string]$entry.Name)
            # Never overwrite a choice made after this script ran.
            if ((-not $now.Exists) -or ($now.Value -ne [int]$entry.Target)) {
                Report 'SKIP' ("Changed since backup or not applied: {0}" -f $known[0].Label)
                $skipped++
                continue
            }
            if ([bool]$entry.Exists) {
                Write-Dword -Path ([string]$entry.Path) -Name ([string]$entry.Name) -Value ([int]$entry.OldValue)
            } else {
                Remove-ItemProperty -LiteralPath ([string]$entry.Path) -Name ([string]$entry.Name) -ErrorAction Stop
            }
            Report 'OK' ("Restored: {0}" -f $known[0].Label)
            $restored++
        } catch {
            Report 'SKIP' ("Restore failed for {0}: {1}" -f $known[0].Label, $_.Exception.Message)
            $failed++
        }
    }
    Report 'DONE' ("Restored=$restored, unchanged/skipped=$skipped, failed=$failed")
    Report 'INFO' '部分外观变化需注销并重新登录后生效。'
    exit 0
}

$changes = New-Object System.Collections.ArrayList
$already = 0; $unsupported = 0; $readFailed = 0
Report 'INFO' ("Windows build: $build | Windows 11: $isWindows11 | Theme: $Theme")
foreach ($item in $settings) {
    if ($item.W11 -and -not $isWindows11) {
        $unsupported++
        Report 'SKIP' ("Windows 11-only: {0}" -f $item.Label)
        continue
    }
    try {
        $old = Registry-State -Path $item.Path -Name $item.Name
        if ($old.Exists -and $old.Value -eq [int]$item.Value) {
            $already++
            Report 'SAME' $item.Label
            continue
        }
        [void]$changes.Add([pscustomobject]@{
            Label    = $item.Label
            Path     = $item.Path
            Name     = $item.Name
            Exists   = [bool]$old.Exists
            OldValue = $old.Value
            Target   = [int]$item.Value
        })
        if ($Preview) {
            Report 'PLAN' ("{0} => {1}" -f $item.Label, $item.Value)
        }
    } catch {
        $readFailed++
        Report 'SKIP' ("Cannot inspect {0}: {1}" -f $item.Label, $_.Exception.Message)
    }
}

if ($Preview) {
    Report 'DONE' ("Preview only: proposed=$($changes.Count), already=$already, unsupported=$unsupported, failures=$readFailed. No changes made.")
    exit 0
}
if ($changes.Count -eq 0) {
    Report 'DONE' ("No changes pending; failed inspections=$readFailed. No backup created.")
    exit 0
}

# Write-ahead backup: abort entirely if a readable backup cannot be saved.
try {
    $backupDir = Join-Path $root 'Backups'
    New-Item -ItemType Directory -Path $backupDir -Force -ErrorAction Stop | Out-Null
    $backupFile = Join-Path $backupDir "backup-$timestamp.json"
    $tempFile = "$backupFile.tmp"
    $payload = [ordered]@{
        Version   = 1
        CreatedAt = (Get-Date).ToString('o')
        User      = [Environment]::UserName
        Machine   = $env:COMPUTERNAME
        Entries   = @($changes.ToArray())
    }
    $payload | ConvertTo-Json -Depth 5 -ErrorAction Stop |
        Set-Content -LiteralPath $tempFile -Encoding UTF8 -ErrorAction Stop
    Move-Item -LiteralPath $tempFile -Destination $backupFile -ErrorAction Stop
    $check = Get-Content -LiteralPath $backupFile -Raw -Encoding UTF8 -ErrorAction Stop |
        ConvertFrom-Json -ErrorAction Stop
    if ([int]$check.Version -ne 1 -or @($check.Entries).Count -ne $changes.Count) {
        throw 'Backup verification failed.'
    }
    $script:LogFile = Join-Path $root "apply-$timestamp.log"
} catch {
    Report 'ERROR' ("Unable to save/verify backup. No settings were changed: {0}" -f $_.Exception.Message)
    exit 1
}

Report 'BACKUP' $backupFile
$changed = 0; $writeFailed = 0
foreach ($entry in $changes) {
    try {
        Write-Dword -Path $entry.Path -Name $entry.Name -Value ([int]$entry.Target)
        Report 'OK' $entry.Label
        $changed++
    } catch {
        Report 'SKIP' ("Cannot change {0}: {1}" -f $entry.Label, $_.Exception.Message)
        $writeFailed++
    }
}
Report 'DONE' ("Changed=$changed, already=$already, unsupported=$unsupported, failed=$($readFailed + $writeFailed)")
Report 'INFO' ("Undo: powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Undo `"$backupFile`"")
Report 'INFO' '部分外观变化需注销并重新登录。未触碰应用、个人文件、系统更新和安全设置。'
